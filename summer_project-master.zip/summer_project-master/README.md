# summer_project
stocks, time series analysis, DNN and so on


## shaokai_jiashen


## qixiao_guang
the output in /data/result.csv
